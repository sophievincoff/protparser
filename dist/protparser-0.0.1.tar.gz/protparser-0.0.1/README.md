# proteinparser
A collection of methods for parsing protein structures (RCSB PDBs, AlphaFold predictions, and more)
